# NEXOS OS — Android starter project

Primeira base nativa Android para o NEXOS OS, com interface horizontal inspirada em console.

## O que já está incluído
- Tela inicial em orientação paisagem.
- Tema preto, roxo e branco.
- Catálogo demonstrativo com busca e filtros PS1 / PS2 / Retro / Todos.
- Página inicial com destaque e cartões de jogos.
- Área "Minha biblioteca".
- Importação de arquivos de jogos usando o seletor de documentos do Android (SAF), sem copiar ROMs para dentro do APK.
- Lista dos arquivos importados durante a sessão atual.

## Importante
- O catálogo inicial usa dados demonstrativos; não inclui ROMs nem links de distribuição de jogos protegidos.
- Para publicar downloads, adicione apenas títulos homebrew, gratuitos ou autorizados pelos respectivos titulares, com URLs e licenças verificadas.
- Importar um arquivo não significa que o aplicativo já consegue executá-lo. A emulação exige integrar um emulador compatível e respeitar sua licença, além dos requisitos legais de BIOS/firmware.
- Os arquivos importados são selecionados pelo usuário. Nesta versão, a lista é mantida apenas enquanto o app estiver aberto; persistência pode ser adicionada depois usando persistência de URIs/Room/DataStore.
- Este é um projeto-fonte para abrir no Android Studio; não é um APK assinado pronto.

## Como abrir
1. Extraia o ZIP.
2. Abra a pasta `NEXOS_OS_Android` no Android Studio.
3. Aguarde o Gradle sincronizar.
4. Execute no emulador ou celular Android.
5. Para melhor experiência, use um aparelho em modo paisagem.

## Próximas etapas sugeridas
1. Criar catálogo real com metadados e fontes de download autorizadas.
2. Guardar biblioteca e URIs entre sessões.
3. Integrar emulador de forma compatível com as licenças aplicáveis.
4. Gerar ícone, splash screen e pacote APK assinado.
