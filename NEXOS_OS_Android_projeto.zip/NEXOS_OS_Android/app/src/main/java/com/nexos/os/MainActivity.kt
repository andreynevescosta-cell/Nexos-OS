package com.nexos.os

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import android.database.Cursor
import android.provider.OpenableColumns

private val Night = Color(0xFF09070F)
private val Panel = Color(0xFF171321)
private val Purple = Color(0xFF9B5CFF)
private val Neon = Color(0xFFC7A2FF)
private val Muted = Color(0xFFB8B0C7)
private val White = Color(0xFFF8F5FF)

data class Game(
    val title: String,
    val system: String,
    val genre: String,
    val description: String,
    val status: String = "Catálogo demonstrativo"
)

data class LocalGameFile(val name: String, val uri: Uri, val size: String)

private val demoGames = listOf(
    Game("Pixel Quest", "PS1", "Aventura", "Aventura independente de demonstração."),
    Game("Neon Circuit", "PS1", "Corrida", "Corridas retrô com visual futurista."),
    Game("Shadow of the Temple", "PS2", "Ação", "Projeto demonstrativo de ação e exploração."),
    Game("Starlight Rally", "PS2", "Corrida", "Velocidade e pistas estilizadas."),
    Game("Castle of Echoes", "PS1", "Plataforma", "Uma jornada de plataforma em estilo clássico."),
    Game("Retro Arena", "Retro", "Arcade", "Desafios arcade para sessões rápidas."),
    Game("Moonlit Garden", "PS2", "Aventura", "Exploração em um mundo fantástico."),
    Game("Velocity X", "PS1", "Corrida", "Corridas arcade de alta velocidade."),
    Game("Arcane Legends", "PS2", "RPG", "Fantasia e progressão de personagens."),
    Game("Bit Raiders", "Retro", "Ação", "Ação retrô em fases curtas."),
    Game("Dreambound", "PS1", "RPG", "RPG de demonstração para o catálogo."),
    Game("Skyline Drift", "PS2", "Corrida", "Drift e pistas noturnas.")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NexosApp() }
    }
}

@Composable
fun NexosApp() {
    var search by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Todos") }
    var tab by remember { mutableStateOf("Descobrir") }
    var selectedGame by remember { mutableStateOf<Game?>(null) }
    var favorites by remember { mutableStateOf(setOf<String>()) }
    var localFiles by remember { mutableStateOf(listOf<LocalGameFile>()) }
    val context = LocalContext.current

    val filePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        val additions = uris.map { uri ->
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {}
            val cursor: Cursor? = context.contentResolver.query(uri, null, null, null, null)
            var name = "Arquivo de jogo"
            var size = "Tamanho desconhecido"
            cursor?.use {
                val nameIndex = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = it.getColumnIndex(OpenableColumns.SIZE)
                if (it.moveToFirst()) {
                    if (nameIndex >= 0) name = it.getString(nameIndex) ?: name
                    if (sizeIndex >= 0 && !it.isNull(sizeIndex)) {
                        val bytes = it.getLong(sizeIndex)
                        size = if (bytes >= 1_000_000_000) "%.2f GB".format(bytes / 1_000_000_000.0)
                        else if (bytes >= 1_000_000) "%.0f MB".format(bytes / 1_000_000.0)
                        else "%.0f KB".format(bytes / 1_000.0)
                    }
                }
            }
            LocalGameFile(name, uri, size)
        }
        localFiles = (localFiles + additions).distinctBy { it.uri.toString() }
        tab = "Minha biblioteca"
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Night, surface = Panel, primary = Purple,
            onPrimary = White, onBackground = White, onSurface = White
        )
    ) {
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xFF10091C), Night, Color(0xFF09070F)))
            )
        ) {
            Column(Modifier.fillMaxSize().padding(horizontal = 28.dp, vertical = 18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("NEXOS", color = White, fontSize = 27.sp, fontWeight = FontWeight.Black, letterSpacing = 4.sp)
                        Text("CONECTANDO GERAÇÕES", color = Neon, fontSize = 8.sp, letterSpacing = 2.sp)
                    }
                    Spacer(Modifier.width(34.dp))
                    listOf("Descobrir", "PS1", "PS2", "Retro", "Minha biblioteca").forEach { item ->
                        val active = tab == item
                        Text(
                            item,
                            modifier = Modifier.clip(RoundedCornerShape(18.dp))
                                .background(if (active) Purple.copy(alpha = .22f) else Color.Transparent)
                                .clickable { tab = item; selectedGame = null }
                                .padding(horizontal = 13.dp, vertical = 9.dp),
                            color = if (active) Neon else Muted,
                            fontSize = 12.sp,
                            fontWeight = if (active) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                    Spacer(Modifier.weight(1f))
                    Icon(Icons.Default.FolderOpen, null, tint = Neon, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(7.dp))
                    Text("${localFiles.size} arquivos", color = Muted, fontSize = 11.sp)
                }

                Spacer(Modifier.height(18.dp))

                if (selectedGame != null) {
                    GameDetail(
                        game = selectedGame!!,
                        isFavorite = favorites.contains(selectedGame!!.title),
                        onBack = { selectedGame = null },
                        onFavorite = {
                            favorites = if (favorites.contains(selectedGame!!.title))
                                favorites - selectedGame!!.title else favorites + selectedGame!!.title
                        }
                    )
                } else if (tab == "Minha biblioteca") {
                    LibraryScreen(localFiles, onAdd = {
                        filePicker.launch(arrayOf("*/*"))
                    }, onRemove = { file -> localFiles = localFiles - file })
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                if (tab == "Descobrir") "Sua próxima aventura começa aqui."
                                else "Explore o catálogo $tab",
                                fontSize = 23.sp, fontWeight = FontWeight.Bold, color = White
                            )
                            Spacer(Modifier.height(4.dp))
                            Text("Um universo de jogos, organizado do seu jeito.", color = Muted, fontSize = 12.sp)
                        }
                        OutlinedTextField(
                            value = search,
                            onValueChange = { search = it },
                            modifier = Modifier.width(255.dp).height(52.dp),
                            placeholder = { Text("Buscar jogos...", fontSize = 12.sp) },
                            leadingIcon = { Icon(Icons.Default.Search, null, tint = Neon) },
                            singleLine = true,
                            shape = RoundedCornerShape(16.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Purple,
                                unfocusedBorderColor = Color(0xFF40364F),
                                focusedTextColor = White,
                                unfocusedTextColor = White
                            )
                        )
                    }

                    Spacer(Modifier.height(16.dp))

                    if (tab == "Descobrir" && search.isBlank()) {
                        HeroBanner(onClick = { selectedGame = demoGames[2] })
                        Spacer(Modifier.height(16.dp))
                    }

                    val filtered = demoGames.filter { game ->
                        val matchesTab = tab == "Descobrir" || game.system.equals(tab, true)
                        val matchesSearch = game.title.contains(search, true) ||
                                game.genre.contains(search, true) ||
                                game.system.contains(search, true)
                        matchesTab && matchesSearch
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(if (search.isBlank()) "EM DESTAQUE" else "RESULTADOS", color = Neon, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        Spacer(Modifier.width(10.dp))
                        Text("${filtered.size} jogos", color = Muted, fontSize = 10.sp)
                    }
                    Spacer(Modifier.height(10.dp))
                    if (filtered.isEmpty()) {
                        Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                            Text("Nenhum jogo encontrado. Tente outro nome ou categoria.", color = Muted)
                        }
                    } else {
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            contentPadding = PaddingValues(bottom = 10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            items(filtered) { game ->
                                GameCard(
                                    game = game,
                                    favorite = favorites.contains(game.title),
                                    onClick = { selectedGame = game },
                                    onFavorite = {
                                        favorites = if (favorites.contains(game.title)) favorites - game.title else favorites + game.title
                                    }
                                )
                            }
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("DISTRIBUIÇÃO AUTORIZADA", color = Muted, fontSize = 9.sp, letterSpacing = 1.5.sp)
                        Spacer(Modifier.width(8.dp))
                        Text("Catálogo demonstrativo • nenhum jogo protegido incluído", color = Muted.copy(alpha = .75f), fontSize = 9.sp)
                        Spacer(Modifier.weight(1f))
                        Text("NEXOS OS  •  v0.1", color = Neon.copy(alpha = .8f), fontSize = 9.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun HeroBanner(onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().height(122.dp).clip(RoundedCornerShape(20.dp))
            .background(Brush.horizontalGradient(listOf(Color(0xFF452079), Color(0xFF211334), Color(0xFF171020))))
            .clickable { onClick() }.padding(horizontal = 22.dp, vertical = 15.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text("NEXOS ORIGINALS", color = Neon, fontSize = 9.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(5.dp))
            Text("Uma nova era do retrô.", color = White, fontSize = 23.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(4.dp))
            Text("Descubra, organize e leve seus jogos com você.", color = Muted, fontSize = 11.sp)
        }
        Box(
            Modifier.size(88.dp).clip(RoundedCornerShape(18.dp))
                .background(Brush.linearGradient(listOf(Purple, Color(0xFF4A1A7C)))),
            contentAlignment = Alignment.Center
        ) {
            Text("N", color = White, fontSize = 52.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
fun GameCard(game: Game, favorite: Boolean, onClick: () -> Unit, onFavorite: () -> Unit) {
    Column(
        Modifier.width(145.dp).clip(RoundedCornerShape(15.dp)).background(Panel)
            .clickable { onClick() }
    ) {
        Box(
            Modifier.fillMaxWidth().height(112.dp).background(
                Brush.linearGradient(
                    when (game.system) {
                        "PS1" -> listOf(Color(0xFF5B2D8D), Color(0xFF17112C))
                        "PS2" -> listOf(Color(0xFF1F5A68), Color(0xFF17112C))
                        else -> listOf(Color(0xFF914C66), Color(0xFF17112C))
                    }
                )
            ),
            contentAlignment = Alignment.Center
        ) {
            Text(game.title.take(1), color = White.copy(alpha = .9f), fontSize = 55.sp, fontWeight = FontWeight.Black)
            Surface(
                color = Color.Black.copy(alpha = .45f),
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.align(Alignment.TopStart).padding(8.dp)
            ) {
                Text(game.system, color = White, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp))
            }
            IconButton(onClick = onFavorite, modifier = Modifier.align(Alignment.TopEnd).size(34.dp)) {
                Icon(if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = if (favorite) Neon else White, modifier = Modifier.size(17.dp))
            }
        }
        Column(Modifier.padding(10.dp)) {
            Text(game.title, color = White, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(3.dp))
            Text(game.genre, color = Muted, fontSize = 10.sp)
            Spacer(Modifier.height(8.dp))
            Text("VER DETALHES  ↗", color = Neon, fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = .5.sp)
        }
    }
}

@Composable
fun GameDetail(game: Game, isFavorite: Boolean, onBack: () -> Unit, onFavorite: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        TextButton(onClick = onBack) {
            Icon(Icons.Default.ArrowBack, null, tint = Neon)
            Spacer(Modifier.width(6.dp))
            Text("Voltar ao catálogo", color = Neon)
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.width(230.dp).fillMaxHeight(.78f).clip(RoundedCornerShape(22.dp))
                    .background(Brush.linearGradient(listOf(Purple, Color(0xFF17112C)))),
                contentAlignment = Alignment.Center
            ) {
                Text(game.title.take(1), color = White, fontSize = 100.sp, fontWeight = FontWeight.Black)
            }
            Spacer(Modifier.width(26.dp))
            Column(Modifier.weight(1f)) {
                Text("${game.system}  •  ${game.genre.uppercase()}", color = Neon, fontSize = 11.sp, letterSpacing = 2.sp)
                Spacer(Modifier.height(8.dp))
                Text(game.title, color = White, fontSize = 30.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.height(12.dp))
                Text(game.description, color = Muted, fontSize = 14.sp)
                Spacer(Modifier.height(18.dp))
                Text("Entrada demonstrativa de catálogo. Fontes de download serão adicionadas apenas quando a distribuição for autorizada.", color = Muted, fontSize = 11.sp)
                Spacer(Modifier.height(18.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = { }, enabled = false, colors = ButtonDefaults.buttonColors(disabledContainerColor = Purple.copy(alpha = .35f))) {
                        Icon(Icons.Default.Download, null)
                        Spacer(Modifier.width(7.dp))
                        Text("Download indisponível")
                    }
                    OutlinedButton(onClick = onFavorite) {
                        Icon(if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null)
                        Spacer(Modifier.width(7.dp))
                        Text(if (isFavorite) "Salvo" else "Favoritar")
                    }
                }
            }
        }
    }
}

@Composable
fun LibraryScreen(files: List<LocalGameFile>, onAdd: () -> Unit, onRemove: (LocalGameFile) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Minha biblioteca", color = White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text("Importe arquivos que você tem direito de usar. Os arquivos ficam no local original.", color = Muted, fontSize = 11.sp)
            }
            Button(onClick = onAdd, colors = ButtonDefaults.buttonColors(containerColor = Purple)) {
                Icon(Icons.Default.Add, null)
                Spacer(Modifier.width(6.dp))
                Text("Adicionar ROMs")
            }
        }
        Spacer(Modifier.height(18.dp))
        if (files.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.FolderOpen, null, tint = Neon, modifier = Modifier.size(42.dp))
                    Spacer(Modifier.height(10.dp))
                    Text("Sua biblioteca começa aqui", color = White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(5.dp))
                    Text("Selecione arquivos .ISO, .BIN, .CUE, .CHD ou outros formatos compatíveis.", color = Muted, fontSize = 11.sp)
                }
            }
        } else {
            Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                files.forEach { file ->
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Panel).padding(13.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.FolderOpen, null, tint = Neon)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(file.name, color = White, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(file.size, color = Muted, fontSize = 10.sp)
                        }
                        TextButton(onClick = { onRemove(file) }) { Text("Remover", color = Neon) }
                    }
                }
            }
        }
    }
}
